package com.springboot.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantRestApi1Application.class, args);
	}

}
