package utility;


import io.appium.java_client.remote.MobileCapabilityType;

public interface MobileCapbilitiesEx  extends MobileCapabilityType{

	String APP_PACKAGE="appPackage";
	String APP_ACTIVITY="appActivity";
	String SERVER="http://0.0.0.0:4723/wd/hub/";
}
