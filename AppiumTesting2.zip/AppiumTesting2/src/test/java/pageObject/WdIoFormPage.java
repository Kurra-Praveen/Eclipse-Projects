package pageObject;

import org.openqa.selenium.By;

public class WdIoFormPage {

	public static String formsPage = "Forms";

	public static String inputFeild = "text-input";

	public static String inputResult = "input-text-result";

	public static String toogleBar = "switch";

	public static String toogleText = "switch-text";

	public static String dropDown = "Dropdown";

	//public static By dropDownItems=By.id("com.wdiodemoapp:id/select_dialog_listview");
	//android:id/text1
	public static By dropDownItems=By.id("android:id/text1");

	public static String activeButton= "button-Active";

	public static By message = By.id("android:id/message");

	public static By quitMessagePopUp = By.id("android:id/button1");
}
