package pageObject;

import org.openqa.selenium.By;

public class WdIoLoginPage {

	public static String loginButton = "Login";

	public static String userNameFeild = "input-email";

	public static String passwordFeild = "input-password";

	public static String submitLoginButton = "button-LOGIN";

	public static By status = By.id("android:id/alertTitle");

	public static By closeStatusWindow = By.id("android:id/button1");

}
