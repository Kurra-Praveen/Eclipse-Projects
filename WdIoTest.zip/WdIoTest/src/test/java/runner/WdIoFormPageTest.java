package runner;

import java.util.List;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.appium.java_client.MobileElement;
import pageObject.WdIoFormPage;
import reusable.BaseClass;


public class WdIoFormPageTest extends BaseClass {


	@Test
	public void Form() {

		test=extentReport.createTest("Login Form");

		webUtils.clickButton(WdIoFormPage.formsPage);

		test.log(Status.INFO,"clicks on form button");

		webUtils.enterText(WdIoFormPage.inputFeild, "Praveen");

		test.log(Status.INFO,"entered the username");

		MobileElement inputResult=webUtils.getMobileElement(WdIoFormPage.inputResult);

		String result=inputResult.getText();

		test.log(Status.INFO,result);

		System.out.println(result);

		webUtils.clickButton(WdIoFormPage.toogleBar);

		test.log(Status.INFO,"clicked on toogle bar");

		String toogleResult=webUtils.getText(WdIoFormPage.toogleText);

		System.out.println(toogleResult);

		test.log(Status.INFO,toogleResult);

		webUtils.clickButton(WdIoFormPage.dropDown);


        List<MobileElement>dropDownelements=  webUtils.getAllMobileElements(WdIoFormPage.dropDownItems);

        for(MobileElement element:dropDownelements) {

       	 String text=element.getText();

       	 if(text.contains("Appium")) {

       		 element.click();

       		test.log(Status.INFO,"click on appium list");

       		 break;
       	 }
        }

		webUtils.clickButton(WdIoFormPage.activeButton);

		String popMessage=webUtils.getText(WdIoFormPage.message);

		System.out.println(popMessage);

		test.log(Status.INFO,popMessage);

		webUtils.clickButton(WdIoFormPage.quitMessagePopUp);



	}
}
