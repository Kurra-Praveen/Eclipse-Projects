package runner;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import pageObject.WdIoLoginPage;
import reusable.BaseClass;
import reusable.ProjectUtilities;


public class WdIoLoginPageTest extends BaseClass {

	@Test
	public void login() {

		test=extentReport.createTest("Login test");

		webUtils.clickButton(WdIoLoginPage.loginButton);

		test.log(Status.INFO,"clicks on login button");

		webUtils.enterText(WdIoLoginPage.userNameFeild, config.getData("username"));

		test.log(Status.INFO,"enterd username");

		String password=config.getData("password");

		webUtils.enterText(WdIoLoginPage.passwordFeild, ProjectUtilities.getDecryptedValue(password));

		test.log(Status.INFO,"entered password");

		webUtils.clickButton(WdIoLoginPage.submitLoginButton);

		test.log(Status.INFO,"clicked on submiit button");

		String result=webUtils.getText(WdIoLoginPage.status);

		test.log(Status.INFO,result);

		if (result.equalsIgnoreCase("Success")) {

			Assert.assertTrue(true);

			test.log(Status.INFO,"assertion passed");

		} else {

			Assert.assertTrue(false);

			test.log(Status.INFO,"assertion failed");
		}

		webUtils.clickButton(WdIoLoginPage.closeStatusWindow);

		test.log(Status.INFO,"closed the window");
	}



}
