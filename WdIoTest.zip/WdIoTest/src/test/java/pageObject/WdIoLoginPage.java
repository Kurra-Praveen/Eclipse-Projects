package pageObject;

public class WdIoLoginPage {
	public static String loginButton = "accesbilityId#Login";

	public static String userNameFeild = "accesbilityId#input-email";

	public static String passwordFeild = "accesbilityId#input-password";

	public static String submitLoginButton = "accesbilityId#button-LOGIN";

	public static String status = "id#android:id/alertTitle";

	public static String closeStatusWindow = "id#android:id/button1";

}
