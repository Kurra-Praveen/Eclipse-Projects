package pageObject;



public class WdIoFormPage {

	public static String formsPage = "accesbilityId#Forms";

	public static String inputFeild = "accesbilityId#text-input";

	public static String inputResult = "accesbilityId#input-text-result";

	public static String toogleBar = "accesbilityId#switch";

	public static String toogleText = "accesbilityId#switch-text";

	public static String dropDown = "accesbilityId#Dropdown";

	public static String dropDownItems="id#android:id/text1";

	public static String activeButton= "accesbilityId#button-Active";

	public static String message = "id#android:id/message";

	public static String quitMessagePopUp = "id#android:id/button1";
}
